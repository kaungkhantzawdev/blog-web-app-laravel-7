<li class="menu-title font-monospace small">
    {{ $name }}
</li>
