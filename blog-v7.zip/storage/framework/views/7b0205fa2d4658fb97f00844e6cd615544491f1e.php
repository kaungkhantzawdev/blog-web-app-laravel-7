<?php $__env->startSection('head'); ?>
    <style>
        .page-item{
            width: 35px;
            height: 35px;
            text-align: center;
            padding: 0;
            line-height: 35px;
        }

        .page-item.active .page-link{
            border-radius: 50% !important;
            border : 1px solid var(--bs-primary) !important;
            background: transparent !important;
            color: var(--bs-primary) !important;
        }
        .page-link{
            padding: 0 !important;
            border: none;
            border-radius: 50% !important;
            font-weight: bold;
        }
        .page-link:hover{
            border-radius: 50% !important;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-12 col-lg-7">
        <div class="">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border-bottom mb-4 pb-4 article-preview">
                <div class="d-flex align-items-center justify-content-between">
                    <a class="fw-bold h4 d-block text-decoration-none" href="">
                        <?php echo e($article->title); ?>

                    </a>
                    <small class="text-black-50"><?php echo e($article->updated_at->diffForHumans()); ?></small>
                </div>

                <div class="small post-category">
                    <a href="" class="btn btn-sm btn-light px-3" style="border-radius: 30px;"><?php echo e($article->category->title); ?></a>
                </div>
                <?php if($article->photo): ?>
                <div class="my-2">
                    <img alt="<?php echo e($article->photo); ?>" src="<?php echo e(isset($article->photo)? asset('storage/article/'.$article->photo): ""); ?>" class="rounded w-100 shadow-sm">
                </div>
                <?php endif; ?>
                <div class="text-black-50 the-excerpt">
                    <p style="white-space: pre-line">
                        <?php echo e($article->excerpt); ?>

                    </p>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(isset($article->user->photo)? asset('storage/profile/'.$article->user->photo) : asset('img/user.png')); ?>" alt="<?php echo e($article->user->photo); ?>" class="rounded-circle" style="object-fit: cover !important; object-position: center !important; width: 50px; height: 50px">
                        <div class="ms-2">
                                  <span class="small">
                                      <i class="bi bi-person"></i>
                                      <?php echo e($article->user->name); ?>

                                  </span>
                            <br>
                            <span class="small"><?php echo e($article->updated_at->format('d M Y')); ?></span>
                        </div>
                    </div>
                    <a href="<?php echo e(route('blog.detail', $article->slug)); ?>" class="btn btn-sm btn-outline-primary px-3" style="border-radius: 30px;">Read More</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="mb-4 pb-4 ">
                    <div class="d-flex justify-content-center">
                        <div class="">
                            <h4 class="">There is no article 😔</h4>
                            <div class="my-2">
                                <p class="mb-0">
                                    Please add article, go to login to Dashboard
                                </p>
                            </div>
                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-sm rounded-pill px-3 btn-primary"><i class="bi bi-grid me-2"></i> Dashboard</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="btn btn-sm rounded-pill px-3 btn-primary me-2">Login</a>
                                    <a href="<?php echo e(route('register')); ?>" class="text-decoration-none">Register</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="d-flex align-items-center justify-content-center">
            <div class=" d-block d-lg-none">
                <?php echo e($articles->onEachSide(1)->appends(Request::all())->links()); ?>

            </div>
        </div>
    </div>
    <div class="col-12 col-lg-5 border-start">
        <div class="">
            <div class="border-bottom mb-4 pb-4">
                <div class="d-flex align-items-center justify-content-between">
                    <a class="fw-bold h4 d-block text-decoration-none" href="">
                        <?php echo e($oldArticle->title); ?>

                    </a>
                    <small class="text-black-50"><?php echo e($oldArticle->updated_at->diffForHumans()); ?></small>
                </div>

                <div class="small post-category">
                    <a href="" class="btn btn-sm btn-light px-3" style="border-radius: 30px;"><?php echo e($oldArticle->category->title); ?></a>
                </div>
                <?php if($oldArticle->photo): ?>
                    <div class="my-2">
                        <img alt="<?php echo e($oldArticle->photo); ?>" src="<?php echo e(isset($oldArticle->photo)? asset('storage/article/'.$oldArticle->photo): asset('img/user.png')); ?>" class="rounded" style="object-fit: cover !important; object-position: center !important; width: 100%; height: 400px">
                    </div>
                <?php endif; ?>
                <div class="text-black-50 the-excerpt">
                    <p style="white-space: pre-line">
                        <?php echo e($oldArticle->excerpt); ?>

                    </p>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(isset($oldArticle->user->photo)? asset('storage/profile/'.$oldArticle->user->photo) : asset('img/user.png')); ?>" alt="<?php echo e($oldArticle->user->photo); ?>" class="rounded-circle" style="object-fit: cover !important; object-position: center !important; width: 50px; height: 50px">
                        <div class="ms-2">
                                  <span class="small">
                                      <i class="bi bi-person"></i>
                                      <?php echo e($oldArticle->user->name); ?>

                                  </span>
                            <br>
                            <span class="small"><?php echo e($oldArticle->updated_at->format('d M Y')); ?></span>
                        </div>
                    </div>
                    <a href="" class="btn btn-sm btn-outline-primary px-3" style="border-radius: 30px;">Read More</a>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-center">
                <div class=" d-none d-lg-block">
                    <?php echo e($articles->onEachSide(1)->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/welcome.blade.php ENDPATH**/ ?>