<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>login</title>
    <link rel="icon" href="<?php echo e(asset('img/logo.svg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="bg-light">

<section class="container">
    <div class="row align-items-center justify-content-center vh-100">
        <div class="col-12 col-mg-6 col-lg-5">
            <div class="">
                <div class="d-flex align-items-center justify-content-center mb-4">
                    <img src="<?php echo e(asset(\App\Base::$logo)); ?>" style="width: 50px" alt="">
                </div>
                <div class="card border-0 shadow-sm">
                    <div class="p-4">
                        <h2 class="text-center font-weight-normal font-monospace">Sign In</h2>
                        <p class="text-center text-black-50 mb-5">
                            Don't have an account yet?
                            <a href="<?php echo e(route('register')); ?>" class="text-decoration-none">Sign up here</a>
                        </p>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="email" class="form-label d-flex align-items-center">
                                    <i class="bi bi-envelope text-primary me-3"></i>
                                    Email address
                                </label>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label d-flex align-items-center">
                                    <i class="bi bi-shield-lock me-3 text-primary"></i>
                                    Password
                                </label>
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Remember Me')); ?>

                                </label>
                            </div>
                            <div class="">
                                <button type="submit" class="btn w-100 btn-primary">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <i class="bi bi-arrow-right"></i>
                                        <span class="ms-3 font-monospace">Login</span>
                                    </div>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="mt-3 text-center">
                    <?php if(Route::has('password.request')): ?>
                        <a class="btn btn-link text-decoration-none" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('foot'); ?>
<?php echo $__env->make('layouts.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>




<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/auth/login.blade.php ENDPATH**/ ?>