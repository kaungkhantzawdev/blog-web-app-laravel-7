<?php if(session('alert')): ?>
    <script>
        let alertInfo = <?php echo json_encode(session('alert'), 15, 512) ?>;
        Swal.fire(
            alertInfo.title,
            alertInfo.message,
            alertInfo.icon
        )
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/layouts/alert.blade.php ENDPATH**/ ?>