<div class="">
    <table class="table table-bordered table-responsive">
        <thead>
        <tr>
            <th>#</th>
            <th>Category Name</th>
            <th>User Name</th>
            <th>Control</th>
            <th>Created at</th>
            <th>Update at</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="align-middle">
                <td><?php echo e($category->id); ?></td>
                <td>
                    <div class="d-flex align-items-center">
                        <span class="ms-2"><?php echo e($category->title); ?></span>
                    </div>
                </td>
                <td><?php echo e($category->user->name); ?></td>
                <td>
                    <button type="button" onclick="return showAlert(<?php echo e($category->id); ?>)"
                            class="btn btn-sm btn-outline-danger" form="form<?php echo e($category->id); ?>">
                        <i class="bi bi-trash3"></i>
                    </button>
                    <form action="<?php echo e(route('category.destroy',$category->id)); ?>" class="d-none" id="form<?php echo e($category->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                    </form>
                    <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                <td>
                    <small>
                        <i class="bi bi-calendar-event"></i>
                        <span class="ms-2">
                                                <?php echo e($category->created_at->format('d m Y')); ?>

                                            </span>
                        <br>
                        <i class="bi bi-clock"></i>
                        <span class="ms-2">
                                                <?php echo e($category->created_at->format('h:i A')); ?>

                                            </span>
                    </small>
                </td>
                <td>
                    <small>
                        <i class="bi bi-calendar-event"></i>
                        <span class="ms-2">
                                                <?php echo e($category->updated_at->format('d m Y')); ?>

                                            </span>
                        <br>
                        <i class="bi bi-clock"></i>
                        <span class="ms-2">
                                                <?php echo e($category->updated_at->format('h:i A')); ?>

                                            </span>
                    </small>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center text-warning">There is no data.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="d-flex align-items-center justify-content-between">
        <div class="">
            <?php echo e($categories->links()); ?>

        </div>
        <div class="">
            <h6 class="mb-0 fw-bold">
                <i class="bi bi-layers me-1"></i>
                Total : <?php echo e($categories->total()); ?>

            </h6>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/category/list.blade.php ENDPATH**/ ?>