<li class="sidebar-item">
    <a href="<?php echo e($link); ?>" class="sidebar-link <?php echo e(request()->url()==$link ? " sidebar-active":""); ?>">
        <i class="bi <?php echo e($class); ?> me-3"></i>
        <?php echo e($name); ?>

    </a>
</li>
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/components/side-bar-item.blade.php ENDPATH**/ ?>