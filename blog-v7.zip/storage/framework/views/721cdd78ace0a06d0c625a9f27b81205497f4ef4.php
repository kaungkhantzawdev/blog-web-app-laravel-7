<?php $__env->startSection('title'); ?> Profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('user.manager')); ?>" class="text-decoration-none">user-manager</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($user->name); ?> information</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="col-12 col-lg-6 col-xl-5">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="">
                    <div class="text-center">
                        <img src="<?php echo e(isset($user->photo)? asset('storage/profile/'.$user->photo): asset('img/user.png')); ?>" alt="" class="rounded-circle img-thumbnail my-3 shadow-sm" style="width: 150px; height: 150px; object-fit: cover; object-position: center">
                        <h3 class="mb-0 font-weight-bold font-monospace">
                            <?php echo e($user->name); ?>

                        </h3>
                        <small class="text-black-50">
                            <?php echo e($user->email); ?>

                        </small>
                    </div>
                    <hr class="bg-secondary text-secondary">
                    <div class="text-black-50">
                        <div class="">
                            <i class="bi bi-person me-3"></i>
                            <span class=""><?php echo e($user->name); ?></span>
                        </div>
                        <div class="my-2">
                            <i class="bi bi-envelope me-3"></i>
                            <span class=""><?php echo e($user->email); ?></span>
                        </div>
                        <div class="">
                            <i class="bi bi-postcard me-3"></i>
                            <span class="">You have been created 35 posts. </span>
                        </div>
                        <div class="my-2">
                            <i class="bi bi-telephone me-3"></i>
                            <span class="">
                                <?php echo e(isset($user->phone)? $user->phone : "Phone Number"); ?>

                            </span>
                        </div>
                        <div class="">
                            <i class="bi bi-geo-alt me-3"></i>
                            <span class="">
                                <?php echo e(isset($user->address)? $user->address : "Address"); ?>

                            </span>
                        </div>
                    </div>
                    <div class="mt-3 d-flex align-items-center justify-content-between">
                        <div class="">
                            <a href="<?php echo e(route('user.manager')); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-people me-2"></i>
                                user list
                            </a>
                        </div>
                        <div class="">
                            <?php if($user->role != 0): ?>
                                <a href="<?php echo e(route('user.info', $user->id)); ?>" class="btn btn-sm btn-outline-primary" title="to see information">
                                    <i class="bi bi-info-circle"></i>
                                </a>

                                <form action="<?php echo e(route('user.makeAdmin', $user->id)); ?>" class="d-none" method="post" id="makeAdmin<?php echo e($user->id); ?>">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <button type="button" class="btn btn-sm btn-outline-warning mx-2" form="makeAdmin<?php echo e($user->id); ?>" title="to make admin"
                                        onclick="return makeAdmin(<?php echo e($user->id); ?>)">
                                    <i class="bi bi-person-circle"></i>
                                </button>
                                <?php if($user->isBanned != 1): ?>
                                    <form action="<?php echo e(route('user.banUser', $user->id)); ?>" class="d-none" method="post" id="banUser<?php echo e($user->id); ?>">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <button type="button" class="btn btn-sm btn-outline-danger" form="banUser<?php echo e($user->id); ?>" title="to make admin"
                                            onclick="return banUser(<?php echo e($user->id); ?>)">
                                        to ban
                                    </button>
                                <?php else: ?>
                                    <form action="<?php echo e(route('user.unbanUser', $user->id)); ?>" class="d-none" method="post" id="unbanUser<?php echo e($user->id); ?>">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <button type="button" class="btn btn-sm btn-outline-danger" form="unbanUser<?php echo e($user->id); ?>" title="to make admin"
                                            onclick="return unbanUser(<?php echo e($user->id); ?>)">
                                        isn't ban
                                    </button>
                                <?php endif; ?>
                            <?php else: ?>
                                <form action="<?php echo e(route('user.unmakeAdmin', $user->id)); ?>" class="d-none" method="post" id="unmakeAdmin<?php echo e($user->id); ?>">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <button type="button" class="btn btn-sm btn-outline-warning" form="unmakeAdmin<?php echo e($user->id); ?>" title="to make admin"
                                        onclick="return unmakeAdmin(<?php echo e($user->id); ?>)">
                                    <i class="bi bi-person-circle me-1"></i>
                                    unmake admin
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-3">
        <span class="text-black-50">Have a great day sir.</span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        function makeAdmin(id) {
            Swal.fire({
                title: 'Are you sure <br> to upgrade role?',
                text: "role ချိန်လိုက်ရင် admin လုပ်ပိုင်ခွင့်များကို ရရှိမှာဖြစ်ပါတယ်။",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Role Updated',
                        'အကောင့်မြှင်တင်ချင်း အောင်မြင်ပါသည်။',
                        'success'
                    );
                    setTimeout(function () {
                        $("#makeAdmin"+id).submit();
                    }, 1500)
                }
            })
        }

        function unmakeAdmin(id) {
            Swal.fire({
                title: 'Are you sure <br> to unmake admin role?',
                text: "role ချိန်လိုက်ရင် admin လုပ်ပိုင်ခွင့်များကို ရရှိမှ မဟုတ်တော့ပါ။",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Role Changed',
                        'အကောင့်မြှင်တင်ချင်း အောင်မြင်ပါသည်။',
                        'success'
                    );
                    setTimeout(function () {
                        $("#unmakeAdmin"+id).submit();
                    }, 1500)
                }
            })
        }

        function banUser(id) {
            Swal.fire({
                title: 'Are you sure <br> to Ban this user?',
                text: "user access banned",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Banned User',
                        'user is banned',
                        'success'
                    );
                    setTimeout(function () {
                        $("#banUser"+id).submit();
                    }, 1500)
                }
            })
        }

        function unbanUser(id) {
            Swal.fire({
                title: 'Are you sure <br> to remove ban list this user?',
                text: "user access",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Remove Ban list this user',
                        'user access',
                        'success'
                    );
                    setTimeout(function () {
                        $("#unbanUser"+id).submit();
                    }, 1500)
                }
            })
        }


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/userManager/info.blade.php ENDPATH**/ ?>