<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-decoration-none">Home</a></li>
        <?php echo e($slot); ?>

    </ol>
</nav>
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/components/bread-crumb.blade.php ENDPATH**/ ?>