<li class="menu-title font-monospace small">
    <?php echo e($name); ?>

</li>
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/components/menu-title.blade.php ENDPATH**/ ?>