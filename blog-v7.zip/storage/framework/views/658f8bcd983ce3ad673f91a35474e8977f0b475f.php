<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title',\App\Base::$name); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/logo.svg')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="bg-light">
<!-- Authentication Links -->
<?php if(auth()->guard()->guest()): ?>
    <a href="<?php echo e(route('login')); ?>" class=""></a>
    <a href="<?php echo e(route('register')); ?>" class=""></a>
<?php else: ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--main-->
    <div class="position-relative">
        <section class="main w-100" id="main">
            <div class="container-fluid">
                <div class="row sub-main px-2 g-0" id="subMain">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <?php echo $__env->yieldContent('content-two'); ?>
            </div>
        </section>
    </div>
    <!--main end-->
<?php endif; ?>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('foot'); ?>
<?php if(auth()->guard()->check()): ?>
    <?php if(empty(Auth::user()->phone)): ?>
        <?php echo $__env->make('profile.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php echo $__env->make('layouts.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/layouts/app.blade.php ENDPATH**/ ?>