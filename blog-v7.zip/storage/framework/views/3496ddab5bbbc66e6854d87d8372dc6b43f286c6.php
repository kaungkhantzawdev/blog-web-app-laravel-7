<!--side bar-->
<aside class="sidebar py-3 px-4 shadow-sm bg-white" id="sidebar">
    <div class="container-fluid px-0">
        <div class="row">
            <div class="col-12">
                <div class="brand d-flex align-items-center justify-content-between">
                    <div class="brand-logo d-flex align-items-center">
                        <img src="<?php echo e(asset(\App\Base::$logo)); ?>" alt="" class="" style="width: 25px">
                        <span class="h4 ms-3 mb-0 fw-bolder font-monospace text-primary">Blog</span>
                    </div>
                    <div class="">
                        <button type="button" class="border-0 bg-white" id="menu-close">
                            <i class="bi bi-x-circle text-secondary" style="font-size: 18px"></i>
                        </button>
                    </div>
                </div>
                <div class="my-3" >
                    <div class="">
                        <ul class="sidebar-menu">
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('home')).'','class' => 'bi-house-door','name' => 'Home']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('welcome')).'','class' => 'bi-box-seam','name' => 'News']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['name' => 'Category']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('category.index')).'','class' => 'bi-layers','name' => 'Category Manager']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                            <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['name' => 'Article']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('article.create')).'','class' => 'bi-plus-circle','name' => 'Create Article']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('article.index')).'','class' => 'bi-list-ul','name' => 'Articles']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                            <?php if(Auth::user()->role != 1): ?>
                             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['name' => 'User']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('user.manager')).'','class' => 'bi-people','name' => 'Users']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>

                             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['name' => 'User Profile']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('profile')).'','class' => 'bi-person','name' => 'Your Profile']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('profile.photo-upload')).'','class' => 'bi-camera','name' => 'Photo Upload']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('profile.updateInfo')).'','class' => 'bi-arrow-up-circle','name' => 'update info']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('profile.changeP')).'','class' => 'bi-shield-lock','name' => 'change password']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['name' => 'Logout']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SideBarItem::class, ['link' => ''.e(route('logout')).'','class' => 'bi-emoji-frown','name' => 'Logout']); ?>
<?php $component->withName('side-bar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2)): ?>
<?php $component = $__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2; ?>
<?php unset($__componentOriginal79d26ea159edaf7f81755013627c70e801d51de2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </ul>
                    </div>
                </div>



















            </div>
        </div>
    </div>
</aside>
<!--side bar end-->
<?php /**PATH C:\Users\RiO\Desktop\blogv7\blog-v7\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>